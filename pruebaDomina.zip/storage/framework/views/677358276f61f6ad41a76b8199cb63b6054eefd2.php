<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title','Prueba'); ?></title>

        <link href="<?php echo e(asset(mix('css/app.css'))); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('DataTables/datatables.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
              <a class="navbar-brand" href="inicio">Prueba</a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item active">
                    <a class="nav-link" href="inicio">Home <span class="sr-only">(current)</span></a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="nomina">Nomina</a>
                  </li>
                </ul>
              </div>
            </nav>
        </div>
        <div class="container">
          <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- JavaScript -->
        <script src="<?php echo e(asset(mix('js/app.js'))); ?>"></script>
        <script src="<?php echo e(asset('DataTables/datatables.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html>
<?php /**PATH C:\xampp64\htdocs\pruebaDomina\resources\views/layout/layout.blade.php ENDPATH**/ ?>